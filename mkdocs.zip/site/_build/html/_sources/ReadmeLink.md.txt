# Getting-Started Guide
```{include} ../README.md
```
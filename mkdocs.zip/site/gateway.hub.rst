gateway.hub package
===================

Submodules
----------

gateway.hub.AdvertisementLogging module
---------------------------------------

.. automodule:: gateway.hub.AdvertisementLogging
   :members:
   :undoc-members:
   :show-inheritance:

gateway.hub.DataFormats module
------------------------------

.. automodule:: gateway.hub.DataFormats
   :members:
   :undoc-members:
   :show-inheritance:

gateway.hub.decoder module
--------------------------

.. automodule:: gateway.hub.decoder
   :members:
   :undoc-members:
   :show-inheritance:

gateway.hub.nix\_hci module
---------------------------

.. automodule:: gateway.hub.nix_hci
   :members:
   :undoc-members:
   :show-inheritance:

gateway.hub.nix\_hci\_dummy module
----------------------------------

.. automodule:: gateway.hub.nix_hci_dummy
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: gateway.hub
   :members:
   :undoc-members:
   :show-inheritance:

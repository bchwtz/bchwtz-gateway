.. gateway documentation master file, created by
   sphinx-quickstart on Tue Feb  1 12:03:46 2022.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to gateway's documentation!
===================================

.. toctree::
   :maxdepth: 2
   :caption: Contents:
   
   git_installation_on_raspberry.md
   intro_to_sphinx.rst
   link_to_readme.md
   unittest.rst
   gateway.hub.rst
   gateway.sensor.rst
   gateway.experimental.flashing.rst



Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
